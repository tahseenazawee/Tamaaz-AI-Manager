package com.mostamsak.scanner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** Offline automatic four-corner document detector. No external dependencies. */
public final class DocumentDetector {
    private DocumentDetector() { }

    public static final class Point {
        public final double x, y;
        public Point(double x, double y) { this.x = x; this.y = y; }
    }
    public static final class Result {
        public final Point[] corners; // TL, TR, BR, BL
        public final double confidence;
        Result(Point[] corners, double confidence) { this.corners = corners; this.confidence = confidence; }
        public boolean found() { return corners != null; }
    }
    private static final class Line {
        final int theta;
        final double rho, c, s;
        final int votes;
        Line(int theta, double rho, int votes, double[] cs, double[] ss) {
            this.theta = theta; this.rho = rho; this.votes = votes;
            this.c = cs[theta]; this.s = ss[theta];
        }
    }
    private static final class Pair {
        final Line a, b;
        final int votes;
        Pair(Line a, Line b) { this.a = a; this.b = b; this.votes = a.votes + b.votes; }
    }

    public static Result detect(int[] argb, int width, int height) {
        if (argb == null || width < 120 || height < 120 || argb.length < width * height)
            return new Result(null, 0);
        // Prefer a full-card color-segmentation outline over internal text lines.
        Result separated = detectByBackgroundColor(argb, width, height);
        if (separated.found()) return separated;
        final int n = width * height;
        int[] gray = new int[n];
        for (int i = 0; i < n; i++) {
            int c = argb[i];
            gray[i] = ((c >> 16 & 255) * 77 + (c >> 8 & 255) * 150 + (c & 255) * 29) >> 8;
        }
        int[] smooth = new int[n];
        for (int y = 1; y < height - 1; y++) for (int x = 1; x < width - 1; x++) {
            int i = y * width + x;
            smooth[i] = (gray[i-width-1] + 2*gray[i-width] + gray[i-width+1]
                    + 2*gray[i-1] + 4*gray[i] + 2*gray[i+1]
                    + gray[i+width-1] + 2*gray[i+width] + gray[i+width+1]) >> 4;
        }
        int[] magnitude = new int[n];
        int[] directions = new int[n];
        int[] histogram = new int[2041];
        int observed = 0;
        // Two-pixel sampling keeps this fast on ordinary mid-range phones.
        for (int y = 2; y < height - 2; y += 2) for (int x = 2; x < width - 2; x += 2) {
            int i = y * width + x;
            int gx = -smooth[i-width-1] + smooth[i-width+1]
                    -2*smooth[i-1]+2*smooth[i+1] - smooth[i+width-1]+smooth[i+width+1];
            int gy = -smooth[i-width-1]-2*smooth[i-width]-smooth[i-width+1]
                    +smooth[i+width-1]+2*smooth[i+width]+smooth[i+width+1];
            int mag = Math.min(2040, Math.abs(gx)+Math.abs(gy));
            magnitude[i] = mag;
            histogram[mag]++;
            observed++;
            double degrees = Math.toDegrees(Math.atan2(gy, gx));
            if (degrees < 0) degrees += 180;
            if (degrees >= 180) degrees -= 180;
            directions[i] = (int)Math.round(degrees) % 180;
        }
        int cumulative = 0, threshold = 70;
        for (int m = 2040; m >= 1; m--) {
            cumulative += histogram[m];
            if (cumulative >= observed * 0.16) { threshold = Math.max(70, m); break; }
        }
        final int diag = (int)Math.ceil(Math.hypot(width, height));
        final int rhoSize = 2 * diag + 1;
        int[] accumulator = new int[180 * rhoSize];
        double[] cos = new double[180], sin = new double[180];
        for (int t = 0; t < 180; t++) {
            cos[t] = Math.cos(Math.toRadians(t)); sin[t] = Math.sin(Math.toRadians(t));
        }
        for (int y = 2; y < height - 2; y += 2) for (int x = 2; x < width - 2; x += 2) {
            int i = y*width+x, mag = magnitude[i];
            if (mag < threshold) continue;
            int dir = directions[i], weight = Math.min(4, 1 + mag / 250);
            for (int d = -2; d <= 2; d += 2) {
                int t = (dir + d + 180) % 180;
                int rho = (int)Math.round(x*cos[t] + y*sin[t]) + diag;
                if (rho >= 0 && rho < rhoSize) accumulator[t*rhoSize + rho] += weight;
            }
        }
        ArrayList<Line> peaks = new ArrayList<>();
        int minVotes = Math.max(26, (width + height) / 42);
        for (int t = 0; t < 180; t++) for (int r = 0; r < rhoSize; r++) {
            int v = accumulator[t * rhoSize + r];
            if (v < minVotes) continue;
            boolean peak = true;
            for (int dt = -2; dt <= 2 && peak; dt++) {
                int tt = (t+dt+180)%180;
                for (int dr = -5; dr <= 5; dr++) {
                    int rr = r + dr;
                    if (rr < 0 || rr >= rhoSize || (dt == 0 && dr == 0)) continue;
                    // A wrap around of theta reverses rho sign.
                    if (t + dt < 0 || t + dt >= 180) rr = 2*diag-rr;
                    if (rr >= 0 && rr < rhoSize && accumulator[tt*rhoSize+rr] > v) { peak = false; break; }
                }
            }
            if (peak) peaks.add(new Line(t, r-diag, v, cos, sin));
        }
        peaks.sort((a,b) -> Integer.compare(b.votes, a.votes));
        ArrayList<Line> lines = new ArrayList<>();
        for (Line item: peaks) {
            if (lines.size() >= 34) break;
            boolean near = false;
            for (Line prior: lines) {
                int angular = Math.abs(prior.theta-item.theta);
                angular = Math.min(angular, 180-angular);
                double distanceAtCenter = Math.abs((prior.rho-prior.c*width/2.0-prior.s*height/2.0) -
                        (item.rho-item.c*width/2.0-item.s*height/2.0));
                if (angular <= 8 && distanceAtCenter < 15) { near = true; break; }
            }
            if (!near) lines.add(item);
        }
        ArrayList<Pair> pairs = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) for (int j = i+1; j < lines.size(); j++) {
            Line a = lines.get(i), b = lines.get(j);
            int angular = Math.abs(a.theta-b.theta);
            if (Math.min(angular, 180-angular) > 17) continue;
            double ra = a.rho-a.c*width/2.0-a.s*height/2.0;
            double rb = b.rho-b.c*width/2.0-b.s*height/2.0;
            double sep = Math.abs(ra-rb);
            if (sep < 0.23*Math.min(width,height) || sep > 1.07*Math.hypot(width,height)) continue;
            pairs.add(new Pair(a,b));
        }
        pairs.sort((a,b)->Integer.compare(b.votes,a.votes));
        if (pairs.size() > 75) pairs.subList(75,pairs.size()).clear();
        Point[] best = null;
        double bestScore = 0, bestConfidence = 0;
        for (int i = 0; i < pairs.size(); i++) for (int j = i+1; j < pairs.size(); j++) {
            Pair p = pairs.get(i), q = pairs.get(j);
            int angle = Math.abs(p.a.theta-q.a.theta);
            if (angle < 64 || angle > 116) continue;
            Point[] raw = new Point[]{intersect(p.a,q.a),intersect(p.a,q.b),
                    intersect(p.b,q.b),intersect(p.b,q.a)};
            if (Arrays.stream(raw).anyMatch(v -> v == null || !Double.isFinite(v.x) || !Double.isFinite(v.y))) continue;
            Point[] quad = order(raw);
            if (!valid(quad,width,height)) continue;
            double area = polygonArea(quad), ratio = area/(width*(double)height);
            if (ratio < 0.13 || ratio > 1.06) continue;
            double support = 0;
            double minSupport = 1;
            for (int k = 0; k < 4; k++) {
                double s = edgeSupport(quad[k],quad[(k+1)%4],magnitude,threshold,width,height);
                support += s; minSupport = Math.min(minSupport,s);
            }
            support /= 4;
            if (support < 0.57 || minSupport < 0.43) continue;
            double vote = p.votes + q.votes;
            double score = vote * (0.40+0.60*support) * (0.65+0.35*Math.sqrt(ratio));
            if (score > bestScore) {
                bestScore = score;
                best = quad;
                bestConfidence = support;
            }
        }
        return new Result(best, bestConfidence);
    }

    /** Segment a document against a fairly uniform table/background. */
    private static Result detectByBackgroundColor(int[] pixels,int w,int h){
        int n=w*h, size=Math.max(6,Math.min(w,h)/22);
        int[][] average=new int[4][3];
        int k=0;
        for(int ySide=0;ySide<2;ySide++)for(int xSide=0;xSide<2;xSide++){
            long r=0,g=0,b=0;int count=0;
            for(int y=ySide==0?0:h-size;y<(ySide==0?size:h);y+=2){
                for(int x=xSide==0?0:w-size;x<(xSide==0?size:w);x+=2){
                    int v=pixels[y*w+x];r+=v>>16&255;g+=v>>8&255;b+=v&255;count++;
                }
            }
            average[k][0]=(int)(r/count);average[k][1]=(int)(g/count);average[k][2]=(int)(b/count);k++;
        }
        int maxDist=0;
        for(int i=0;i<4;i++)for(int j=i+1;j<4;j++){
            int dr=average[i][0]-average[j][0],dg=average[i][1]-average[j][1],db=average[i][2]-average[j][2];
            maxDist=Math.max(maxDist,(int)Math.sqrt(dr*dr+dg*dg+db*db));
        }
        if(maxDist>66)return new Result(null,0); // irregular background
        int br=0,bg=0,bb=0;
        for(int[] rgb:average){br+=rgb[0];bg+=rgb[1];bb+=rgb[2];}
        br/=4;bg/=4;bb/=4;
        int threshold=Math.max(27,Math.min(66, maxDist*2+20));
        int thresholdSquared=threshold*threshold;
        byte[] mask=new byte[n];
        for(int i=0;i<n;i++){
            int v=pixels[i];int dr=(v>>16&255)-br,dg=(v>>8&255)-bg,db=(v&255)-bb;
            if(dr*dr+dg*dg+db*db>=thresholdSquared)mask[i]=1;
        }
        int[] queue=new int[n];
        Point[] best=null;int bestCount=0;
        for(int start=0;start<n;start++){
            if(mask[start]!=1)continue;
            mask[start]=2;
            int front=0,back=0;queue[back++]=start;
            int minSum=Integer.MAX_VALUE,maxSum=Integer.MIN_VALUE;
            int maxDiff=Integer.MIN_VALUE,minDiff=Integer.MAX_VALUE;
            Point tl=null,tr=null,bl=null,rb=null;
            double sx=0,sy=0;
            while(front<back){
                int v=queue[front++],x=v%w,y=v/w;
                sx+=x;sy+=y;
                if(x+y<minSum){minSum=x+y;tl=new Point(x,y);}
                if(x+y>maxSum){maxSum=x+y;rb=new Point(x,y);}
                if(x-y>maxDiff){maxDiff=x-y;tr=new Point(x,y);}
                if(x-y<minDiff){minDiff=x-y;bl=new Point(x,y);}
                if(x>0&&mask[v-1]==1){mask[v-1]=2;queue[back++]=v-1;}
                if(x+1<w&&mask[v+1]==1){mask[v+1]=2;queue[back++]=v+1;}
                if(y>0&&mask[v-w]==1){mask[v-w]=2;queue[back++]=v-w;}
                if(y+1<h&&mask[v+w]==1){mask[v+w]=2;queue[back++]=v+w;}
            }
            if(back<=bestCount||back<0.13*n||back>0.93*n)continue;
            if(Math.abs(sx/back-w*0.5)>w*0.31||Math.abs(sy/back-h*0.5)>h*0.31)continue;
            Point[] p = new Point[]{tl,tr,rb,bl};
            if(!valid(p,w,h))continue;
            double area=polygonArea(p);
            if(area/(w*(double)h)<0.13||area/(w*(double)h)>1.05)continue;
            if(area/back<0.79||area/back>1.36)continue;
            best=p;bestCount=back;
        }
        if(best!=null)return new Result(best,Math.min(1.0,bestCount/(double)polygonArea(best)));
        return new Result(null,0);
    }

    private static Point intersect(Line a, Line b) {
        double determinant = a.c*b.s-b.c*a.s;
        if (Math.abs(determinant) < 0.25) return null;
        return new Point((a.rho*b.s-b.rho*a.s)/determinant,
                (a.c*b.rho-b.c*a.rho)/determinant);
    }
    private static Point[] order(Point[] points) {
        double cx = 0, cy = 0;
        for (Point p:points) { cx+=p.x; cy+=p.y; }
        final double mx=cx/4, my=cy/4;
        Point[] sorted = points.clone();
        Arrays.sort(sorted, Comparator.comparingDouble(p->Math.atan2(p.y-my,p.x-mx)));
        int start=0;
        for (int i=1;i<4;i++) if (sorted[i].x+sorted[i].y < sorted[start].x+sorted[start].y) start=i;
        Point[] out=new Point[4];
        for(int i=0;i<4;i++) out[i]=sorted[(start+i)%4];
        return out;
    }
    private static boolean valid(Point[] p,int w,int h) {
        double cx=0,cy=0;
        for(Point q:p){
            if (q.x < -0.08*w || q.x > 1.08*w || q.y < -0.08*h || q.y > 1.08*h) return false;
            cx+=q.x;cy+=q.y;
        }
        cx/=4;cy/=4;
        if(cx<0.2*w || cx>0.8*w || cy<0.2*h || cy>0.8*h) return false;
        double top=distance(p[0],p[1]), bot=distance(p[2],p[3]);
        double left=distance(p[0],p[3]), right=distance(p[1],p[2]);
        double aspect=(top+bot)/(left+right);
        if(aspect < 0.31 || aspect > 3.25) return false;
        if(polygonArea(p) < 0.01*w*h) return false;
        for(int i=0;i<4;i++){
            Point a=p[(i+3)%4],b=p[i],c=p[(i+1)%4];
            double ux=a.x-b.x,uy=a.y-b.y,vx=c.x-b.x,vy=c.y-b.y;
            double cosine=(ux*vx+uy*vy)/Math.max(0.00001,Math.hypot(ux,uy)*Math.hypot(vx,vy));
            if(Math.abs(cosine)>0.66) return false; // 49 to 131 degrees
        }
        return true;
    }
    private static double edgeSupport(Point a,Point b,int[] mag,int threshold,int w,int h){
        int hits=0, samples=52;
        for(int i=1;i<=samples;i++){
            double f=i/(samples+1.0);
            int x=(int)Math.round(a.x+(b.x-a.x)*f),y=(int)Math.round(a.y+(b.y-a.y)*f);
            boolean found=false;
            for(int oy=-4;oy<=4&&!found;oy+=2)for(int ox=-4;ox<=4;ox+=2){
                int xx=x+ox,yy=y+oy;
                if(xx<2||xx>=w-2||yy<2||yy>=h-2)continue;
                xx=xx/2*2;yy=yy/2*2;
                if(mag[yy*w+xx]>=threshold){found=true;break;}
            }
            if(found)hits++;
        }
        return hits/(double)samples;
    }
    private static double polygonArea(Point[] p){
        double a=0;
        for(int i=0;i<4;i++)a+=p[i].x*p[(i+1)%4].y-p[(i+1)%4].x*p[i].y;
        return Math.abs(a)*0.5;
    }
    private static double distance(Point a,Point b){return Math.hypot(a.x-b.x,a.y-b.y);}
}
