package com.mostamsak.scanner;

import android.graphics.Bitmap;
import java.util.Arrays;

/** Detect, perspective-correct and enhance a real photo; never edits document fields. */
public final class DocumentProcessor {
    private DocumentProcessor() { }
    public static final class Result {
        public final Bitmap image;
        public final boolean cropped;
        public final double confidence;
        Result(Bitmap image, boolean cropped, double confidence) {
            this.image = image; this.cropped = cropped; this.confidence = confidence;
        }
    }
    public static Result process(Bitmap original) {
        if (original == null) throw new IllegalArgumentException("صورة غير صالحة");
        int iw = original.getWidth(), ih = original.getHeight();
        if (iw < 100 || ih < 100) throw new IllegalArgumentException("الصورة صغيرة جداً");
        double scale = Math.min(1.0, 850.0 / Math.max(iw, ih));
        int sw = Math.max(100, (int)Math.round(iw * scale));
        int sh = Math.max(100, (int)Math.round(ih * scale));
        Bitmap small = Bitmap.createScaledBitmap(original, sw, sh, true);
        int[] sample = new int[sw*sh];
        small.getPixels(sample, 0, sw, 0, 0, sw, sh);
        DocumentDetector.Result detected = DocumentDetector.detect(sample, sw, sh);
        if (small != original) small.recycle();
        Bitmap corrected;
        if (detected.found()) {
            DocumentDetector.Point[] p = new DocumentDetector.Point[4];
            double dx = iw/(double)sw, dy = ih/(double)sh;
            double cx=0,cy=0;
            for(int i=0;i<4;i++){
                p[i]=new DocumentDetector.Point(detected.corners[i].x*dx,detected.corners[i].y*dy);
                cx+=p[i].x;cy+=p[i].y;
            }
            cx/=4;cy/=4;
            // Preserve document edges; add a very small margin outward.
            for(int i=0;i<4;i++){
                double x = Math.max(0, Math.min(iw-1, p[i].x + (p[i].x-cx)*0.012));
                double y = Math.max(0, Math.min(ih-1, p[i].y + (p[i].y-cy)*0.012));
                p[i] = new DocumentDetector.Point(x,y);
            }
            corrected=warp(original,p);
        } else {
            // If the four edges cannot be found reliably, don't discard ID details.
            int max = Math.max(iw,ih);
            corrected = max > 2800 ? Bitmap.createScaledBitmap(original,iw*2800/max,ih*2800/max,true)
                    : original.copy(Bitmap.Config.ARGB_8888, true);
        }
        Bitmap enhanced = enhance(corrected);
        corrected.recycle();
        return new Result(enhanced,detected.found(),detected.confidence);
    }

    private static Bitmap warp(Bitmap image, DocumentDetector.Point[] p) {
        int srcW=image.getWidth(),srcH=image.getHeight();
        double top=dist(p[0],p[1]),bottom=dist(p[2],p[3]);
        double left=dist(p[0],p[3]),right=dist(p[1],p[2]);
        double desiredW=(top+bottom)/2,desiredH=(left+right)/2;
        double factor=Math.min(1.0,2800.0/Math.max(desiredW,desiredH));
        int w=Math.max(1,(int)Math.round(desiredW*factor));
        int h=Math.max(1,(int)Math.round(desiredH*factor));
        if ((long)w*h>8_000_000) {
            double s=Math.sqrt(8_000_000.0/(w*(double)h));
            w=Math.max(1,(int)(w*s)); h=Math.max(1,(int)(h*s));
        }
        double dx1=p[1].x-p[2].x,dy1=p[1].y-p[2].y;
        double dx2=p[3].x-p[2].x,dy2=p[3].y-p[2].y;
        double dx3=p[0].x-p[1].x+p[2].x-p[3].x;
        double dy3=p[0].y-p[1].y+p[2].y-p[3].y;
        double g=0,hp=0;
        if(Math.abs(dx3)+Math.abs(dy3)>0.0001){
            double determinant=dx1*dy2-dx2*dy1;
            if(Math.abs(determinant)>1e-7){
                g=(dx3*dy2-dx2*dy3)/determinant;
                hp=(dx1*dy3-dx3*dy1)/determinant;
            }
        }
        double a=p[1].x-p[0].x+g*p[1].x;
        double b=p[3].x-p[0].x+hp*p[3].x;
        double c=p[0].x;
        double d=p[1].y-p[0].y+g*p[1].y;
        double e=p[3].y-p[0].y+hp*p[3].y;
        double f=p[0].y;
        int[] source = new int[srcW*srcH];
        image.getPixels(source,0,srcW,0,0,srcW,srcH);
        int[] dest = new int[w*h];
        for(int y=0;y<h;y++){
            double v=(y+0.5)/h;
            for(int x=0;x<w;x++){
                double u=(x+0.5)/w;
                double divisor=g*u+hp*v+1;
                double sx=(a*u+b*v+c)/divisor;
                double sy=(d*u+e*v+f)/divisor;
                sx=Math.max(0,Math.min(srcW-1.001,sx));
                sy=Math.max(0,Math.min(srcH-1.001,sy));
                int ix=(int)sx,iy=(int)sy;
                double fx=sx-ix,fy=sy-iy;
                int p00=source[iy*srcW+ix],p10=source[iy*srcW+Math.min(srcW-1,ix+1)];
                int p01=source[Math.min(srcH-1,iy+1)*srcW+ix];
                int p11=source[Math.min(srcH-1,iy+1)*srcW+Math.min(srcW-1,ix+1)];
                int red=interp(p00>>16&255,p10>>16&255,p01>>16&255,p11>>16&255,fx,fy);
                int green=interp(p00>>8&255,p10>>8&255,p01>>8&255,p11>>8&255,fx,fy);
                int blue=interp(p00&255,p10&255,p01&255,p11&255,fx,fy);
                dest[y*w+x]=0xff000000|(red<<16)|(green<<8)|blue;
            }
        }
        Bitmap out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        out.setPixels(dest,0,w,0,0,w,h);
        return out;
    }
    private static double dist(DocumentDetector.Point a,DocumentDetector.Point b){
        return Math.hypot(a.x-b.x,a.y-b.y);
    }
    private static int interp(int a,int b,int c,int d,double u,double v){
        return clamp((int)Math.round((a*(1-u)+b*u)*(1-v)+(c*(1-u)+d*u)*v));
    }
    private static int clamp(int v){return Math.max(0,Math.min(255,v));}

    /** Conservative color enhancement + local sharpening, not generative reconstruction. */
    private static Bitmap enhance(Bitmap input){
        int w=input.getWidth(),h=input.getHeight();
        int[] src=new int[w*h],out=new int[w*h];
        input.getPixels(src,0,w,0,0,w,h);
        int[] hist=new int[256];
        for(int i=0;i<src.length;i+=Math.max(1,src.length/100000)){
            int px=src[i];int lum=((px>>16&255)*77+(px>>8&255)*150+(px&255)*29)>>8;
            hist[lum]++;
        }
        int total=Arrays.stream(hist).sum(),position=0,p95=210;
        for(int i=0;i<256;i++){
            position+=hist[i];if(position>=total*0.95){p95=i;break;}
        }
        double gain=p95<210?Math.min(1.23,219.0/Math.max(1,p95)):1.0;
        for(int y=0;y<h;y++)for(int x=0;x<w;x++){
            int i=y*w+x;
            int c=src[i],up=src[Math.max(0,y-1)*w+x],down=src[Math.min(h-1,y+1)*w+x];
            int left=src[y*w+Math.max(0,x-1)],right=src[y*w+Math.min(w-1,x+1)];
            int rr=channel(c,up,down,left,right,16,gain);
            int gg=channel(c,up,down,left,right,8,gain);
            int bb=channel(c,up,down,left,right,0,gain);
            out[i]=0xff000000|(rr<<16)|(gg<<8)|bb;
        }
        Bitmap result=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        result.setPixels(out,0,w,0,0,w,h);
        return result;
    }
    private static int channel(int c,int a,int b,int d,int e,int shift,double gain){
        int base=c>>shift&255;
        int blurred=((a>>shift&255)+(b>>shift&255)+(d>>shift&255)+(e>>shift&255))/4;
        int sharp=clamp((int)Math.round(base+0.35*(base-blurred)));
        return clamp((int)Math.round(((sharp-128)*1.045+128)*gain));
    }
}
