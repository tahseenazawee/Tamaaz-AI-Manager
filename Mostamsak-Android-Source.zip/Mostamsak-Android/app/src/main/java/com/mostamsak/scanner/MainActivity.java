package com.mostamsak.scanner;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One-tap Arabic document scanner, with entirely on-device image processing. */
public class MainActivity extends Activity {
    private static final int REQUEST_CAMERA = 401, REQUEST_GALLERY = 402;
    private static final int BG = Color.rgb(7,21,37), PANEL = Color.rgb(15,35,57);
    private static final int MUTED = Color.rgb(164,187,207), PRIMARY = Color.rgb(23,128,214);
    private Uri cameraCaptureUri, savedImageUri;
    private Bitmap lastResult;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean busy;
    private ImageView preview;
    private TextView status;
    private Button cameraButton, galleryButton, shareButton, openButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildInterface();
    }
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+0.5f);}
    private GradientDrawable shape(int color,int radius){
        GradientDrawable d = new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;
    }
    private TextView text(String title,int size,int color,boolean bold){
        TextView v=new TextView(this);
        v.setText(title);v.setTextSize(size);v.setTextColor(color);
        v.setGravity(Gravity.CENTER);v.setTextDirection(View.TEXT_DIRECTION_RTL);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private void gap(LinearLayout col,int height){View v=new View(this);col.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private Button button(String label,int color){
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);
        b.setTextColor(Color.WHITE);b.setTextSize(17);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(color,16));
        b.setMinHeight(dp(59));b.setElevation(dp(3));
        return b;
    }
    private void buildInterface(){
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackgroundColor(BG);
        outer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        outer.setOnApplyWindowInsetsListener((v,insets)->{
            int top=insets.getSystemWindowInsetTop(),bottom=insets.getSystemWindowInsetBottom();
            v.setPadding(0,top,0,bottom);return insets;
        });
        setContentView(outer);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);outer.addView(scroll);
        LinearLayout col=new LinearLayout(this);col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(18),dp(17),dp(18),dp(20));
        scroll.addView(col,new ScrollView.LayoutParams(-1,-2));
        TextView symbol=text("▣",46,Color.rgb(77,181,252),true);col.addView(symbol);
        TextView title=text("مستمسك",30,Color.WHITE,true);col.addView(title);
        gap(col,6);
        TextView tagline=text("صوّر المستمسك... والباقي علينا",17,MUTED,false);col.addView(tagline);
        gap(col,24);
        cameraButton=button("📷   تصوير مستمسك",PRIMARY);
        col.addView(cameraButton,new LinearLayout.LayoutParams(-1,dp(62)));
        cameraButton.setOnClickListener(v->capture());
        gap(col,10);
        galleryButton=button("اختيار صورة من المعرض",PANEL);
        col.addView(galleryButton,new LinearLayout.LayoutParams(-1,dp(56)));
        galleryButton.setOnClickListener(v->gallery());
        gap(col,18);
        status=text("صور المستمسك مرة واحدة، والتطبيق يصححه ويحفظه كصورة تلقائياً.",15,MUTED,false);
        status.setPadding(dp(10),dp(10),dp(10),dp(10));
        status.setBackground(shape(PANEL,15));
        col.addView(status,new LinearLayout.LayoutParams(-1,-2));
        gap(col,14);
        LinearLayout photoBox=new LinearLayout(this);photoBox.setOrientation(LinearLayout.VERTICAL);
        photoBox.setBackground(shape(PANEL,18));
        photoBox.setPadding(dp(7),dp(7),dp(7),dp(7));
        col.addView(photoBox,new LinearLayout.LayoutParams(-1,dp(350)));
        preview=new ImageView(this);preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setContentDescription("معاينة الصورة المصححة");
        photoBox.addView(preview,new LinearLayout.LayoutParams(-1,-1));
        // No sample ID / personal information displayed before the user takes a photo.
        gap(col,14);
        shareButton=button("مشاركة الصورة المصححة",Color.rgb(18,91,151));
        col.addView(shareButton,new LinearLayout.LayoutParams(-1,dp(55)));
        shareButton.setOnClickListener(v->share());
        gap(col,9);
        openButton=button("فتح الصورة المحفوظة",PANEL);
        col.addView(openButton,new LinearLayout.LayoutParams(-1,dp(53)));
        openButton.setOnClickListener(v->openSaved());
        shareButton.setEnabled(false);openButton.setEnabled(false);
        shareButton.setAlpha(.38f);openButton.setAlpha(.38f);
        gap(col,16);
        TextView privacy=text("✓ مجاني بالكامل    ✓ بدون إنترنت    ✓ صورة JPG فقط\nتتم معالجة المستمسك على جهازك دون إرسال البيانات لأي خادم.",13,MUTED,false);
        privacy.setLineSpacing(dp(4),1f);
        col.addView(privacy);
    }
    private void busy(boolean newValue){
        busy=newValue;cameraButton.setEnabled(!busy);galleryButton.setEnabled(!busy);
        cameraButton.setAlpha(busy?.5f:1f);galleryButton.setAlpha(busy?.5f:1f);
    }
    private void capture(){
        if(busy)return;
        try{
            ContentValues values=new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME,"mostamsak_temp_"+System.currentTimeMillis()+".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/Mostamsak");
            values.put(MediaStore.Images.Media.IS_PENDING,1);
            cameraCaptureUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
            if(cameraCaptureUri==null)throw new IOException("لا يمكن فتح مساحة الصور");
            Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT,cameraCaptureUri);
            intent.setClipData(ClipData.newUri(getContentResolver(),"لقطة المستمسك",cameraCaptureUri));
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent,REQUEST_CAMERA);
        }catch(Exception e){
            removeTemp();showError("تعذر فتح الكاميرا: "+friendly(e));
        }
    }
    private void gallery(){
        if(busy)return;
        try{
            Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("image/*");intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent,REQUEST_GALLERY);
        }catch(ActivityNotFoundException e){showError("لم يتم العثور على معرض صور متوافق.");}
    }
    @Override protected void onActivityResult(int request,int resultCode,Intent data){
        super.onActivityResult(request,resultCode,data);
        if(request==REQUEST_CAMERA){
            Uri image=cameraCaptureUri;
            if(resultCode==RESULT_OK&&image!=null)process(image,true);
            else {removeTemp();status.setText("تم إلغاء التصوير.");}
        }else if(request==REQUEST_GALLERY&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            process(data.getData(),false);
        }
    }
    private void process(Uri input,boolean deleteTemporary){
        busy(true);
        status.setText("جارِ اكتشاف المستمسك وتصحيح صورته تلقائياً...");
        worker.execute(()->{
            Bitmap original=null;
            try{
                ImageDecoder.Source source=ImageDecoder.createSource(getContentResolver(),input);
                original=ImageDecoder.decodeBitmap(source,(decoder,info,src)->{
                    Size sz=info.getSize();int maximum=Math.max(sz.getWidth(),sz.getHeight());
                    decoder.setTargetSampleSize(Math.max(1,(int)Math.ceil(maximum/2800.0)));
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                });
                DocumentProcessor.Result processed=DocumentProcessor.process(original);
                Uri saved=saveJpg(processed.image);
                runOnUiThread(()->{
                    if(lastResult!=null&&lastResult!=processed.image)lastResult.recycle();
                    lastResult=processed.image;savedImageUri=saved;
                    preview.setImageBitmap(lastResult);
                    String note=processed.cropped
                            ?"✓ تم قصّ المستمسك وتصحيح الميل والإضاءة تلقائياً، وحُفظت صورة JPG في المعرض."
                            :"✓ حُفظت الصورة بعد تحسين الإضاءة والحدة. لم تُكتشف جميع الحواف؛ جرّب التصوير فوق خلفية مختلفة حتى تُقص تلقائياً.";
                    status.setText(note);shareButton.setEnabled(true);openButton.setEnabled(true);
                    shareButton.setAlpha(1f);openButton.setAlpha(1f);busy(false);
                });
            }catch(Exception|OutOfMemoryError e){
                runOnUiThread(()->{showError("تعذر تصحيح الصورة: "+friendly(e));busy(false);});
            }finally{
                if(original!=null)original.recycle();
                if(deleteTemporary)deleteTemp(input);
            }
        });
    }
    private Uri saveJpg(Bitmap image) throws IOException{
        ContentValues values=new ContentValues();
        String time=new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date());
        values.put(MediaStore.Images.Media.DISPLAY_NAME,"Mostamsak_"+time+".jpg");
        values.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
        values.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/Mostamsak");
        values.put(MediaStore.Images.Media.IS_PENDING,1);
        Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(uri==null)throw new IOException("تعذر إنشاء ملف JPG");
        try{
            try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                if(out==null||!image.compress(Bitmap.CompressFormat.JPEG,95,out))
                    throw new IOException("تعذر حفظ الصورة");
            }
            ContentValues finish=new ContentValues();finish.put(MediaStore.Images.Media.IS_PENDING,0);
            getContentResolver().update(uri,finish,null,null);
            return uri;
        }catch(Exception e){getContentResolver().delete(uri,null,null);throw new IOException(e);}
    }
    private void share(){
        if(savedImageUri==null)return;
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("image/jpeg");send.putExtra(Intent.EXTRA_STREAM,savedImageUri);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        send.setClipData(ClipData.newUri(getContentResolver(),"مستمسك",savedImageUri));
        startActivity(Intent.createChooser(send,"مشاركة صورة المستمسك"));
    }
    private void openSaved(){
        if(savedImageUri==null)return;
        Intent view=new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(savedImageUri,"image/jpeg");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try{startActivity(view);}catch(ActivityNotFoundException e){
            Toast.makeText(this,"الصورة محفوظة في المعرض / Mostamsak",Toast.LENGTH_LONG).show();
        }
    }
    private void deleteTemp(Uri uri){
        if(uri!=null)try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
        if(uri!=null&&uri.equals(cameraCaptureUri))cameraCaptureUri=null;
    }
    private void removeTemp(){deleteTemp(cameraCaptureUri);}
    private void showError(String error){status.setText(error);Toast.makeText(this,error,Toast.LENGTH_LONG).show();}
    private String friendly(Throwable error){return error.getMessage()==null?"خطأ غير متوقع":error.getMessage();}
    @Override protected void onDestroy(){
        super.onDestroy();worker.shutdown();
    }
}
